"""Máquina de estados autônoma e retomável para a classificação da taxonomia médica MedSync.

Implementa os ciclos de vida definidos para a taxonomia semântica em camada sombra:
- pending -> classified -> requires_high_effort -> verified / requires_review -> approved -> published
- Tratamento explícito de falhas temporárias (quota/rede) vs ambiguidade clínica.
- Zero mutações em tabelas de produção (exam_questions).
- Checkpoints atômicos por lote com cursor_after_id.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Callable

from services.content_taxonomy_classifier import (
    AUTO_VERIFY_THRESHOLD,
    ClassificationOutcome,
    ContentItem,
    TaxonomyDecision,
    VerificationDecision,
    resolve_outcome,
    taxonomy_codes,
)


class TaxonomyItemState(str, enum.Enum):
    PENDING = "pending"
    CLASSIFIED = "classified"
    REQUIRES_HIGH_EFFORT = "requires_high_effort"
    VERIFIED = "verified"
    REQUIRES_REVIEW = "requires_review"
    FAILED = "failed"
    APPROVED = "approved"
    PUBLISHED = "published"


class QuotaExhaustedError(Exception):
    """Exceção levantada quando a cota do modelo é temporariamente esgotada."""

    def __init__(self, message: str = "Cota de processamento do modelo esgotada. Execução pausada com segurança."):
        super().__init__(message)


HIGH_EFFORT_CONDITIONS = {
    "low_confidence_threshold": 0.85,
    "generic_subjects": frozenset({"geral", "outros", "outras", "indefinido", "diversos", "cirurgia geral", "clinica geral"}),
}


def should_require_high_effort(
    item: ContentItem,
    first_pass: TaxonomyDecision,
    verifier_pass: VerificationDecision | None = None,
) -> tuple[bool, str | None]:
    """Determina se o item exige esforço computacional e clínico aprofundado (high effort)."""
    # 1. Baixa confiança no primeiro passe
    if first_pass.confidence < HIGH_EFFORT_CONDITIONS["low_confidence_threshold"]:
        return True, f"Confiança inicial ({first_pass.confidence:.2f}) abaixo do limiar padrão de 0.85"

    # 2. Ambiguidade clínica identificada
    if first_pass.ambiguity_reason:
        return True, f"Ambiguidade clínica detectada: {first_pass.ambiguity_reason}"

    # 3. Assunto classificado ainda genérico
    if first_pass.subject.strip().lower() in HIGH_EFFORT_CONDITIONS["generic_subjects"]:
        return True, f"Assunto gerado '{first_pass.subject}' permanece genérico"

    # 4. Divergência de especialidade ou tema com metadados de origem
    if item.current_specialty and first_pass.specialty.lower() != item.current_specialty.lower():
        # Conflito potencial entre metadados legados e inferência
        if "outros" not in item.current_specialty.lower():
            return True, f"Conflito entre especialidade de origem ('{item.current_specialty}') e classificada ('{first_pass.specialty}')"

    # 5. Discordância do verificador
    if verifier_pass and not verifier_pass.agrees:
        return True, f"Discordância entre classificador e verificador: {verifier_pass.reason}"

    return False, None


@dataclass
class PilotCheckpoint:
    run_id: str
    cursor_after_id: str | None = None
    processed_count: int = 0
    verified_count: int = 0
    review_count: int = 0
    failed_count: int = 0
    high_effort_count: int = 0
    status: str = "preparando"
    last_checkpoint_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_ids: set[str] = field(default_factory=set)


class ResumablePilotExecutor:
    """Orquestrador de execução em lotes retomáveis para o piloto de taxonomia."""

    def __init__(
        self,
        classifier_fn: Callable[[list[ContentItem]], list[TaxonomyDecision]],
        verifier_fn: Callable[[list[ContentItem], list[TaxonomyDecision]], list[VerificationDecision]],
        high_effort_fn: Callable[[list[ContentItem], list[TaxonomyDecision]], list[TaxonomyDecision]] | None = None,
        chunk_size: int = 10,
        verify_threshold: float = AUTO_VERIFY_THRESHOLD,
    ):
        self.classifier_fn = classifier_fn
        self.verifier_fn = verifier_fn
        self.high_effort_fn = high_effort_fn
        self.chunk_size = chunk_size
        self.verify_threshold = verify_threshold

    def execute_chunk(
        self,
        items: list[ContentItem],
        checkpoint: PilotCheckpoint,
    ) -> list[dict[str, Any]]:
        """Executa um chunk atômico de itens e atualiza o checkpoint."""
        results: list[dict[str, Any]] = []

        # Filtrar itens já processados para garantir idempotência e não retrabalho
        pending_items = [it for it in items if it.content_id not in checkpoint.completed_ids]
        if not pending_items:
            return results

        # 1. Passe de Classificação Primária
        decisions = self.classifier_fn(pending_items)
        decisions_by_id = {d.content_id: d for d in decisions}

        # 2. Avaliação de Necessidade de High Effort
        high_effort_candidates: list[ContentItem] = []
        normal_candidates: list[ContentItem] = []

        for it in pending_items:
            dec = decisions_by_id[it.content_id]
            req_he, reason = should_require_high_effort(it, dec)
            if req_he and self.high_effort_fn is not None:
                high_effort_candidates.append(it)
            else:
                normal_candidates.append(it)

        # 3. Processamento de High Effort se aplicável
        if high_effort_candidates and self.high_effort_fn:
            refined_decisions = self.high_effort_fn(
                high_effort_candidates,
                [decisions_by_id[it.content_id] for it in high_effort_candidates],
            )
            for r in refined_decisions:
                decisions_by_id[r.content_id] = r
            checkpoint.high_effort_count += len(high_effort_candidates)

        # 4. Passe de Verificação Independente
        verifications = self.verifier_fn(
            pending_items,
            [decisions_by_id[it.content_id] for it in pending_items],
        )
        verifications_by_id = {v.content_id: v for v in verifications}

        # 5. Resolução de Desfecho e Atribuição de Estados
        for it in pending_items:
            first = decisions_by_id[it.content_id]
            second = verifications_by_id[it.content_id]
            outcome = resolve_outcome(first, second, threshold=self.verify_threshold)

            spec_code, theme_code, subj_code = taxonomy_codes(
                outcome.decision.specialty,
                outcome.decision.theme,
                outcome.decision.subject,
            )

            # Mapear estado final para camada sombra
            final_status = (
                TaxonomyItemState.VERIFIED.value
                if outcome.status == "verificada"
                else TaxonomyItemState.REQUIRES_REVIEW.value
            )

            record = {
                "content_id": it.content_id,
                "content_type": it.content_type,
                "source_hash": it.source_hash(),
                "specialty_code": spec_code,
                "specialty_label": outcome.decision.specialty,
                "theme_code": theme_code,
                "theme_label": outcome.decision.theme,
                "subject_code": subj_code,
                "subject_label": outcome.decision.subject,
                "learning_objectives": outcome.decision.learning_objectives,
                "competencies": outcome.decision.competencies,
                "clinical_contexts": outcome.decision.clinical_contexts,
                "tags": outcome.decision.tags,
                "difficulty": outcome.decision.difficulty,
                "confidence": outcome.confidence,
                "status": final_status,
                "evidence": outcome.decision.evidence,
                "ambiguity_reason": outcome.reason,
            }
            results.append(record)

            # Atualizar checkpoint
            checkpoint.completed_ids.add(it.content_id)
            checkpoint.processed_count += 1
            if final_status == TaxonomyItemState.VERIFIED.value:
                checkpoint.verified_count += 1
            else:
                checkpoint.review_count += 1
            checkpoint.cursor_after_id = str(it.content_id)

        checkpoint.last_checkpoint_at = datetime.now(UTC)
        return results
