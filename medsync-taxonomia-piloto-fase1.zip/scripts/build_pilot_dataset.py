"""Seleção estratificada e determinística do piloto de calibração da taxonomia médica MedSync.

Garante amostragem reproduzível a partir de uma semente fixa (seed=20260910),
cobrindo todas as especialidades disponíveis, casos genéricos, temas/assuntos repetidos,
áreas de alto risco, diversidade de instituições e anos.

Regra de Segurança:
O manifesto gerado contém APENAS identificadores seguros, hashes, campos taxonômicos
atuais e motivos de seleção. NENHUM texto de questão, enunciado ou alternativa é gravado no manifesto.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
import re
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

DEFAULT_SEED = 20260910
DEFAULT_TARGET_COUNT = 3000

HIGH_RISK_KEYWORDS = (
    "trauma",
    "politrauma",
    "choque",
    "sepse",
    "septic",
    "parada",
    "pcr",
    "reanimação",
    "emergência",
    "urgência",
    "infarto",
    "iam",
    "avc",
    "tromboembolismo",
    "hemorragia",
    "intoxicação",
    "insuficiência respiratória",
    "coma",
    "choque anafilático",
    "eclampsia",
    "descolamento prévio",
)

GENERIC_TERMS = {
    "outros",
    "outras",
    "geral",
    "clínica geral",
    "clínica médica",
    "cirurgia geral",
    "indefinido",
    "não informada",
    "diversos",
}

MULTIDISCIPLINAR_KEYWORDS = (
    "gestante",
    "criança",
    "recém-nascido",
    "idoso",
    "oncologia",
    "paliativo",
    "ética",
    "bioética",
    "perícia",
    "psicossomática",
)


def compute_source_hash(item: dict[str, Any]) -> str:
    """Gera hash SHA-256 estável e determinístico para o item de conteúdo."""
    payload = {
        "content_id": str(item.get("id") or item.get("source_id") or ""),
        "content_type": "questao",
        "title": str(item.get("cabecalho") or ""),
        "body": str(item.get("statement_plain") or item.get("enunciado") or ""),
        "current_specialty": item.get("especialidade"),
        "current_theme": item.get("tema"),
        "current_subject": item.get("subtema") or item.get("assunto"),
    }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def detect_selection_reasons(item: dict[str, Any]) -> list[str]:
    """Identifica as razões clínicas e metodológicas para inclusão do item no piloto."""
    reasons: list[str] = []

    specialty = (item.get("especialidade") or "").strip()
    theme = (item.get("tema") or "").strip()
    subject = (item.get("subtema") or item.get("assunto") or "").strip()
    enunciado = (item.get("statement_plain") or item.get("enunciado") or "").lower()

    # 1. Rótulos genéricos
    if specialty.lower() in GENERIC_TERMS:
        reasons.append("generic_specialty")
    if subject.lower() in GENERIC_TERMS or theme.lower() in GENERIC_TERMS:
        reasons.append("generic_theme_or_subject")

    # 2. Tema e assunto idênticos / repetidos
    if theme and subject and theme.lower() == subject.lower():
        reasons.append("repeated_theme_subject")

    # 3. Informação taxonômica ausente ou rasa
    if not theme or not subject:
        reasons.append("missing_subject_or_theme")

    # 4. Áreas clínicas de alto risco (urgência/emergência/crítico)
    if any(kw in subject.lower() or kw in theme.lower() or kw in enunciado[:300] for kw in HIGH_RISK_KEYWORDS):
        reasons.append("high_risk_clinical")

    # 5. Multidisciplinaridade e intersecção
    if any(kw in enunciado for kw in MULTIDISCIPLINAR_KEYWORDS):
        reasons.append("multidisciplinary_overlap")

    # 6. Diversidade institucional e temporal
    if item.get("instituicao"):
        reasons.append("institution_coverage")
    if item.get("ano"):
        reasons.append("temporal_coverage")

    # 7. Especialidade canônica
    if specialty:
        reasons.append(f"specialty_{specialty.lower().replace(' ', '_')}")

    if not reasons:
        reasons.append("standard_curriculum")

    return sorted(reasons)


def primary_stratum(reasons: list[str]) -> str:
    """Define o estrato primário para balanceamento de amostragem."""
    priority_order = [
        "repeated_theme_subject",
        "missing_subject_or_theme",
        "generic_theme_or_subject",
        "generic_specialty",
        "high_risk_clinical",
        "multidisciplinary_overlap",
    ]
    for p in priority_order:
        if p in reasons:
            return p
    for r in reasons:
        if r.startswith("specialty_"):
            return r
    return "standard_curriculum"


def load_raw_candidates(
    db_path: Path | None = None,
    json_gz_path: Path | None = None,
    fixture_path: Path | None = None,
) -> list[dict[str, Any]]:
    """Carrega candidatos de fontes locais autorizadas de forma segura e somente leitura."""
    candidates: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    # 1. Carregar de fixture (se fornecido ou se existir)
    if fixture_path and fixture_path.exists():
        with open(fixture_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                row = json.loads(line)
                cid = str(row.get("id") or row.get("source_id") or "")
                if cid and cid not in seen_ids:
                    seen_ids.add(cid)
                    candidates.append(row)

    # 2. Carregar de question_catalog.json.gz (se existir)
    if json_gz_path and json_gz_path.exists():
        with gzip.open(json_gz_path, "rt", encoding="utf-8") as f:
            catalog = json.load(f)
            if isinstance(catalog, list):
                for row in catalog:
                    cid = str(row.get("id") or row.get("source_id") or "")
                    if cid and cid not in seen_ids:
                        seen_ids.add(cid)
                        candidates.append(row)

    # 3. Carregar de medsync.db se ainda não carregado
    if not candidates and db_path and db_path.exists():
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        for row in cur.execute("SELECT * FROM exam_questions ORDER BY id"):
            cid = str(row["id"])
            if cid not in seen_ids:
                seen_ids.add(cid)
                candidates.append(dict(row))
        conn.close()

    return candidates


def build_stratified_pilot(
    candidates: list[dict[str, Any]],
    target_count: int = DEFAULT_TARGET_COUNT,
    seed: int = DEFAULT_SEED,
) -> dict[str, Any]:
    """Realiza seleção estratificada determinística e produz o manifesto seguro do piloto."""
    rng = random.Random(seed)

    # Agrupar itens por estrato primário
    strata: dict[str, list[dict[str, Any]]] = defaultdict(list)
    enriched_items: list[tuple[dict[str, Any], list[str], str, str]] = []

    for item in candidates:
        cid = str(item.get("id") or item.get("source_id") or "")
        reasons = detect_selection_reasons(item)
        stratum = primary_stratum(reasons)
        source_hash = compute_source_hash(item)
        strata[stratum].append(item)
        enriched_items.append((item, reasons, stratum, source_hash))

    total_available = len(candidates)
    sample_target = min(target_count, total_available)

    # Ordenar deterministamente os candidatos dentro de cada estrato antes de embaralhar
    for stratum_name in strata:
        strata[stratum_name].sort(key=lambda x: str(x.get("id") or x.get("source_id") or ""))
        rng.shuffle(strata[stratum_name])

    selected: list[dict[str, Any]] = []
    selected_ids: set[str] = set()

    # Garantir cotas mínimas para estratos críticos
    critical_strata = [
        "repeated_theme_subject",
        "missing_subject_or_theme",
        "generic_theme_or_subject",
        "generic_specialty",
        "high_risk_clinical",
        "multidisciplinary_overlap",
    ]

    # Fase A: Coleta de estratos prioritários
    for strat in critical_strata:
        pool = strata.get(strat, [])
        for item in pool:
            cid = str(item.get("id") or item.get("source_id") or "")
            if cid not in selected_ids and len(selected) < sample_target:
                selected_ids.add(cid)
                selected.append(item)

    # Fase B: Seleção proporcional dos demais estratos
    remaining_strata = [s for s in strata if s not in critical_strata]
    remaining_strata.sort()

    while len(selected) < sample_target:
        added_in_round = False
        for strat in remaining_strata:
            pool = strata.get(strat, [])
            for item in pool:
                cid = str(item.get("id") or item.get("source_id") or "")
                if cid not in selected_ids and len(selected) < sample_target:
                    selected_ids.add(cid)
                    selected.append(item)
                    added_in_round = True
                    break
        if not added_in_round:
            break

    # Mapear enriched info por id
    info_by_id = {
        str(item.get("id") or item.get("source_id") or ""): (reasons, stratum, s_hash, item)
        for item, reasons, stratum, s_hash in enriched_items
    }

    manifest_items: list[dict[str, Any]] = []
    reason_counter: Counter[str] = Counter()
    specialty_counter: Counter[str] = Counter()
    stratum_counter: Counter[str] = Counter()
    year_counter: Counter[int] = Counter()
    institution_counter: Counter[str] = Counter()

    for item in selected:
        cid = str(item.get("id") or item.get("source_id") or "")
        reasons, stratum, s_hash, orig = info_by_id[cid]

        for r in reasons:
            reason_counter[r] += 1
        spec = orig.get("especialidade") or "Indefinida"
        specialty_counter[spec] += 1
        stratum_counter[stratum] += 1
        if orig.get("ano"):
            try:
                year_counter[int(orig["ano"])] += 1
            except (ValueError, TypeError):
                pass
        if orig.get("instituicao"):
            institution_counter[str(orig["instituicao"])] += 1

        manifest_items.append({
            "content_id": cid,
            "source_hash": s_hash,
            "current_specialty": orig.get("especialidade"),
            "current_theme": orig.get("tema"),
            "current_subject": orig.get("subtema") or orig.get("assunto"),
            "ano": orig.get("ano"),
            "instituicao": orig.get("instituicao"),
            "banca": orig.get("banca"),
            "stratum": stratum,
            "selection_reasons": reasons,
        })

    manifest_items.sort(key=lambda x: str(x["content_id"]))

    manifest = {
        "schema_version": "1.0",
        "generated_at": datetime.now(UTC).isoformat(),
        "seed": seed,
        "target_count": target_count,
        "total_candidates_available": total_available,
        "selected_count": len(manifest_items),
        "sampling_distribution": {
            "by_specialty": dict(specialty_counter.most_common()),
            "by_primary_stratum": dict(stratum_counter.most_common()),
            "by_selection_reason": dict(reason_counter.most_common()),
            "by_year_top10": dict(year_counter.most_common(10)),
            "by_institution_top10": dict(institution_counter.most_common(10)),
        },
        "items": manifest_items,
    }
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Gera manifesto seguro e determinístico para o piloto de taxonomia.")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED, help="Semente pseudoaleatória determinística.")
    parser.add_argument("--target-count", type=int, default=DEFAULT_TARGET_COUNT, help="Quantidade alvo de questões no piloto.")
    parser.add_argument("--output", type=Path, default=Path("data/pilot_manifest_3000.json"), help="Caminho do manifesto JSON.")
    parser.add_argument("--db-path", type=Path, default=Path("medsync.db"), help="Caminho do banco SQLite local.")
    parser.add_argument("--catalog-gz", type=Path, default=Path("data/question_catalog.json.gz"), help="Caminho do catálogo JSON GZ.")
    parser.add_argument("--fixture", type=Path, default=Path("tests/fixtures/pilot-100-import-ready.jsonl"), help="Caminho da fixture de teste.")
    parser.add_argument("--dry-run", action="store_true", help="Apenas exibe as estatísticas sem gravar o arquivo.")
    args = parser.parse_args()

    print(f"[PREFLIGHT] Carregando candidatos locais...")
    candidates = load_raw_candidates(
        db_path=args.db_path,
        json_gz_path=args.catalog_gz,
        fixture_path=args.fixture,
    )
    print(f"[PREFLIGHT] Candidatos carregados: {len(candidates)}")

    if not candidates:
        print("[ERRO] Nenhum candidato encontrado nas fontes locais autorizadas.")
        return

    manifest = build_stratified_pilot(
        candidates,
        target_count=args.target_count,
        seed=args.seed,
    )

    print(f"[PILOTO] Selecionados: {manifest['selected_count']} de {manifest['total_candidates_available']} candidatos.")
    print(f"[PILOTO] Distribuição por estrato primário:")
    for strat, count in manifest["sampling_distribution"]["by_primary_stratum"].items():
        print(f"  - {strat}: {count}")

    print(f"[PILOTO] Distribuição por motivo de seleção (top 10):")
    for reason, count in list(manifest["sampling_distribution"]["by_selection_reason"].items())[:10]:
        print(f"  - {reason}: {count}")

    if not args.dry_run:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)
        print(f"[OK] Manifesto gravado com sucesso em: {args.output}")


if __name__ == "__main__":
    main()
