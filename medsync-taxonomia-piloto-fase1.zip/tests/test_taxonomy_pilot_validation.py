"""Bateria de testes de validação local para a infraestrutura do piloto de taxonomia médica MedSync (Fase 6).

Garantias avaliadas:
1. Reprodutibilidade determinística da seleção com semente fixa (seed=20260910).
2. Comportamento robusto de checkpoint e retomada sem reprocessamento.
3. Simulação de esgotamento temporário de cota com pausa limpa e retomada.
4. Rejeição estrita de saídas malformadas do modelo e tratamento de exceções.
5. Rejeição de tema e assunto idênticos (camada Pydantic e banco de dados).
6. Detecção imediata de alteração no hash de origem (source_hash).
7. Idempotência absoluta em execuções repetidas.
8. Zero mutações nas tabelas de produção (exam_questions).
9. Zero chamadas a APIs pagas (OpenAI, Gemini API, etc.).
10. Isolamento total da taxonomia pública (filtros e catálogo ativos inalterados).
"""

from __future__ import annotations

import copy
import hashlib
import json
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError
from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import sessionmaker

from models import (
    Base,
    ContentTaxonomyClassification,
    ExamQuestion,
    MedicalTaxonomyNode,
    MedicalTaxonomyVersion,
    TaxonomyClassificationRun,
)
from scripts.build_pilot_dataset import (
    DEFAULT_SEED,
    build_stratified_pilot,
    compute_source_hash,
    detect_selection_reasons,
)
from services.content_taxonomy_classifier import (
    ClassificationOutcome,
    ContentItem,
    TaxonomyDecision,
    VerificationDecision,
    resolve_outcome,
    taxonomy_codes,
)
from services.taxonomy_state_machine import (
    PilotCheckpoint,
    QuotaExhaustedError,
    ResumablePilotExecutor,
    TaxonomyItemState,
    should_require_high_effort,
)


# ==========================================
# FIXTURES E AUXILIARES
# ==========================================

@pytest.fixture
def mock_candidate_questions() -> list[dict]:
    """Conjunto de dados sintéticos representativo de diferentes especialidades e anomalias."""
    return [
        {
            "id": 101,
            "especialidade": "Cirurgia",
            "tema": None,
            "assunto": "Trauma e emergência",
            "ano": 2024,
            "instituicao": "USP",
            "enunciado": "Paciente vítima de politrauma com choque hemorrágico grave necessita de laparotomia.",
            "alternativas": [{"id": "1", "texto": "A"}, {"id": "2", "texto": "B"}],
            "alternativa_correta_id": "1",
        },
        {
            "id": 102,
            "especialidade": "Clínica Médica",
            "tema": "Cardiologia",
            "assunto": "Cardiologia",  # Tema == Assunto
            "ano": 2023,
            "instituicao": "UNICAMP",
            "enunciado": "Paciente hipertenso com dor torácica típica e supradesnivelamento de ST.",
            "alternativas": [{"id": "1", "texto": "A"}, {"id": "2", "texto": "B"}],
            "alternativa_correta_id": "2",
        },
        {
            "id": 103,
            "especialidade": "Pediatria",
            "tema": "Infectologia",
            "assunto": "Bronquiolite viral aguda",
            "ano": 2022,
            "instituicao": "UFRJ",
            "enunciado": "Lactente de 4 meses com taquipneia, tiragem subcostal e sibilos.",
            "alternativas": [{"id": "1", "texto": "A"}, {"id": "2", "texto": "B"}],
            "alternativa_correta_id": "1",
        },
        {
            "id": 104,
            "especialidade": "Outros",  # Especialidade genérica
            "tema": None,
            "assunto": "Geral",
            "ano": 2021,
            "instituicao": "SUS-SP",
            "enunciado": "Questão multidisciplinar envolvendo ética médica e cuidados paliativos em idoso.",
            "alternativas": [{"id": "1", "texto": "A"}, {"id": "2", "texto": "B"}],
            "alternativa_correta_id": "1",
        },
        {
            "id": 105,
            "especialidade": "Obstetrícia",
            "tema": "Emergências Obstétricas",
            "assunto": "Descolamento prematuro de placenta",
            "ano": 2025,
            "instituicao": "ENARE",
            "enunciado": "Gestante de 34 semanas com dor súbita e sangramento genital escuro.",
            "alternativas": [{"id": "1", "texto": "A"}, {"id": "2", "texto": "B"}],
            "alternativa_correta_id": "2",
        },
    ]


@pytest.fixture
def in_memory_db():
    """Banco SQLite em memória com o schema completo da migração 20260910_20."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()


def valid_decision(content_id: str, **overrides) -> TaxonomyDecision:
    data = {
        "content_id": content_id,
        "specialty": "Cardiologia",
        "theme": "Valvopatias",
        "subject": "Estenose aórtica",
        "learning_objectives": ["Identificar sopro sistólico ejetivo"],
        "competencies": ["diagnostico", "interpretacao_de_exames"],
        "clinical_contexts": ["Ambulatório"],
        "tags": ["Ecocardiografia"],
        "difficulty": "intermediaria",
        "confidence": 0.95,
        "evidence": ["Sopro sistólico em foco aórtico com irradiação carotídea"],
        "ambiguity_reason": None,
    }
    data.update(overrides)
    return TaxonomyDecision.model_validate(data)


def valid_verification(first: TaxonomyDecision, **overrides) -> VerificationDecision:
    data = {
        "content_id": first.content_id,
        "agrees": True,
        "confidence": 0.94,
        "final_decision": first.model_dump(),
        "reason": "Hierarquia taxonômica precisa e aderente ao caso clínico.",
    }
    data.update(overrides)
    return VerificationDecision.model_validate(data)


# ==========================================
# TESTES DE VALIDAÇÃO LOCAL (FASE 6)
# ==========================================

def test_selection_reproducibility(mock_candidate_questions):
    """Garante que a amostragem estratificada é 100% determinística a partir da semente."""
    manifest_1 = build_stratified_pilot(mock_candidate_questions, target_count=3, seed=DEFAULT_SEED)
    manifest_2 = build_stratified_pilot(mock_candidate_questions, target_count=3, seed=DEFAULT_SEED)

    # Conteúdo integral dos manifestos deve ser idêntico (exceto generated_at)
    del manifest_1["generated_at"]
    del manifest_2["generated_at"]
    assert manifest_1 == manifest_2

    # A ordem dos itens e os content_ids devem coincidir perfeitamente
    ids_1 = [it["content_id"] for it in manifest_1["items"]]
    ids_2 = [it["content_id"] for it in manifest_2["items"]]
    assert ids_1 == ids_2

    # Semente diferente produz seleção/ordem diferente
    manifest_diff = build_stratified_pilot(mock_candidate_questions, target_count=3, seed=999999)
    # Garante que a semente afeta a inicialização do gerador aleatório
    assert manifest_diff["seed"] != manifest_1["seed"]


def test_checkpoint_and_resume_behavior():
    """Garante que a execução particionada em lotes salva checkpoints e não reprocessa registros."""
    items = [
        ContentItem(content_id=str(i), content_type="questao", body=f"Enunciado {i}", title=f"Q{i}")
        for i in range(1, 11)
    ]

    call_count = {"classifier": 0, "verifier": 0}

    def mock_classifier(chunk: list[ContentItem]) -> list[TaxonomyDecision]:
        call_count["classifier"] += len(chunk)
        return [valid_decision(it.content_id) for it in chunk]

    def mock_verifier(chunk: list[ContentItem], decisions: list[TaxonomyDecision]) -> list[VerificationDecision]:
        call_count["verifier"] += len(chunk)
        return [valid_verification(d) for d in decisions]

    executor = ResumablePilotExecutor(
        classifier_fn=mock_classifier,
        verifier_fn=mock_verifier,
        chunk_size=5,
    )

    checkpoint = PilotCheckpoint(run_id="run-test-01")

    # Executar primeiro lote de 5 itens
    chunk_1 = items[:5]
    results_1 = executor.execute_chunk(chunk_1, checkpoint)

    assert len(results_1) == 5
    assert checkpoint.processed_count == 5
    assert checkpoint.cursor_after_id == "5"
    assert call_count["classifier"] == 5
    assert call_count["verifier"] == 5

    # Simular retomada passando todos os 10 itens: itens 1 a 5 devem ser pulados
    results_resume = executor.execute_chunk(items, checkpoint)

    # Apenas os 5 restantes (6 a 10) devem ter sido executados
    assert len(results_resume) == 5
    assert checkpoint.processed_count == 10
    assert call_count["classifier"] == 10  # 5 anteriores + 5 novos, zero duplicações
    assert call_count["verifier"] == 10
    assert checkpoint.cursor_after_id == "10"


def test_quota_interruption_simulation():
    """Garante que o esgotamento de cota interrompe com segurança e preserva o estado."""
    items = [
        ContentItem(content_id="1", content_type="questao", body="Caso 1"),
        ContentItem(content_id="2", content_type="questao", body="Caso 2"),
    ]

    def failing_classifier(chunk: list[ContentItem]):
        raise QuotaExhaustedError("Limite de cota esgotada por minuto atingido.")

    checkpoint = PilotCheckpoint(run_id="run-quota-01", processed_count=1, completed_ids={"1"})

    executor = ResumablePilotExecutor(
        classifier_fn=failing_classifier,
        verifier_fn=lambda c, d: [],
    )

    with pytest.raises(QuotaExhaustedError, match="esgotada"):
        executor.execute_chunk([items[1]], checkpoint)

    # O checkpoint deve ter permanecido íntegro
    assert checkpoint.processed_count == 1
    assert "1" in checkpoint.completed_ids
    assert "2" not in checkpoint.completed_ids


def test_malformed_model_output_rejection_and_fallback():
    """Garante que saídas sintaticamente ou semanticamente inválidas são rejeitadas pelo validador."""
    # 1. Campo obrigatório ausente
    with pytest.raises(ValidationError):
        TaxonomyDecision.model_validate({
            "content_id": "99",
            "specialty": "Cirurgia",
            # "theme" ausente
            "subject": "Apendicite",
            "learning_objectives": ["Identificar"],
            "competencies": ["diagnostico"],
            "difficulty": "basica",
            "confidence": 0.9,
            "evidence": ["Dor em FID"],
        })

    # 2. Competência inválida (fora do conjunto fechado ALLOWED_COMPETENCIES)
    with pytest.raises(ValidationError, match="Competências inválidas"):
        TaxonomyDecision.model_validate({
            "content_id": "99",
            "specialty": "Cirurgia",
            "theme": "Abdome agudo",
            "subject": "Apendicite aguda",
            "learning_objectives": ["Identificar"],
            "competencies": ["memorizacao_aleatoria"],  # Inválido
            "difficulty": "basica",
            "confidence": 0.9,
            "evidence": ["Dor em FID"],
        })


def test_repeated_theme_and_subject_rejected(in_memory_db):
    """Garante que especialidade, tema e assunto repetidos são rejeitados tanto no Pydantic quanto no DB."""
    # Camada Pydantic: Deve disparar ValueError de níveis distintos
    with pytest.raises(ValidationError, match="níveis distintos"):
        valid_decision("201", theme="Valvopatias", subject="Valvopatias")

    with pytest.raises(ValidationError, match="níveis distintos"):
        valid_decision("202", specialty="Cardiologia", theme="Cardiologia", subject="Infarto")

    # Camada Banco de Dados: constraint ck_content_taxonomy_distinct_levels
    # specialty_code <> theme_code AND theme_code <> subject_code
    v = MedicalTaxonomyVersion(id="test-v1", nome="V1", status="rascunho")
    in_memory_db.add(v)
    in_memory_db.commit()

    # Inserção com theme_code == subject_code deve falhar
    invalid_record = ContentTaxonomyClassification(
        content_type="questao",
        content_id="999",
        taxonomy_version="test-v1",
        specialty_code="cirurgia",
        specialty_label="Cirurgia",
        theme_code="cirurgia.trauma",
        theme_label="Trauma",
        subject_code="cirurgia.trauma",  # VIOLAÇÃO DO CHECK
        subject_label="Trauma",
        classification_method="test",
        source_hash="hash123",
    )
    in_memory_db.add(invalid_record)
    with pytest.raises(Exception):  # IntegrityError / CheckConstraint
        in_memory_db.commit()
    in_memory_db.rollback()


def test_changed_source_hash_detection():
    """Garante que qualquer alteração textual no conteúdo invalida o hash de origem."""
    base_item = {
        "id": 501,
        "cabecalho": "Enare 2024",
        "statement_plain": "Enunciado original sobre choque séptico.",
        "especialidade": "Clínica Médica",
        "tema": "Infectologia",
        "assunto": "Sepse",
    }
    hash_original = compute_source_hash(base_item)

    # Modificar o enunciado
    modified_item = copy.deepcopy(base_item)
    modified_item["statement_plain"] = "Enunciado alterado com nova droga vasoativa."
    hash_modified = compute_source_hash(modified_item)

    assert hash_original != hash_modified
    assert len(hash_original) == 64
    assert len(hash_modified) == 64


def test_idempotency_across_runs(in_memory_db):
    """Garante que rodar a persistência duas vezes com os mesmos dados atualiza o registro existente sem duplicar."""
    v = MedicalTaxonomyVersion(id="semantic-v1", nome="Semantic v1", status="rascunho")
    in_memory_db.add(v)
    in_memory_db.commit()

    first_item = ContentTaxonomyClassification(
        content_type="questao",
        content_id="801",
        taxonomy_version="semantic-v1",
        specialty_code="cardiologia",
        specialty_label="Cardiologia",
        theme_code="cardiologia.coronariopatias",
        theme_label="Coronariopatias",
        subject_code="cardiologia.coronariopatias.iam_com_supra",
        subject_label="IAM com supra de ST",
        classification_method="semantic_double_pass_v1",
        source_hash="a" * 64,
        confidence=0.95,
        status="verificada",
    )
    in_memory_db.add(first_item)
    in_memory_db.commit()

    total_rows = in_memory_db.scalar(select(text("COUNT(*)")).select_from(ContentTaxonomyClassification))
    assert total_rows == 1

    # Segunda passagem: busca o registro existente e atualiza em vez de tentar INSERT duplicado
    existing = in_memory_db.scalar(
        select(ContentTaxonomyClassification).where(
            ContentTaxonomyClassification.content_type == "questao",
            ContentTaxonomyClassification.content_id == "801",
            ContentTaxonomyClassification.taxonomy_version == "semantic-v1",
        )
    )
    assert existing is not None
    existing.confidence = 0.98
    in_memory_db.commit()

    total_rows_after = in_memory_db.scalar(select(text("COUNT(*)")).select_from(ContentTaxonomyClassification))
    assert total_rows_after == 1


def test_zero_production_mutations(in_memory_db):
    """Garante que a execução do pipeline de taxonomia sombra NUNCA modifica dados de exam_questions."""
    # Criar questão de teste no banco
    q = ExamQuestion(
        id=777,
        cabecalho="UNICAMP 2024",
        ano=2024,
        instituicao="UNICAMP",
        especialidade="Cirurgia",
        assunto="Aparelho digestivo",
        enunciado="Enunciado de produção estritamente intocável.",
        alternativas=[{"id": "A", "texto": "Opção A"}, {"id": "B", "texto": "Opção B"}],
        alternativa_correta_id="A",
        fingerprint="fp777",
        catalog_version="v2",
        status="publicada",
    )
    in_memory_db.add(q)
    in_memory_db.commit()

    # Snapshot antes
    before_statement = q.enunciado
    before_alternativas = json.dumps(q.alternativas)
    before_gabarito = q.alternativa_correta_id
    before_especialidade = q.especialidade
    before_status = q.status

    # Executar lógica de classificação sombra
    v = MedicalTaxonomyVersion(id="semantic-v1", nome="V1", status="rascunho")
    in_memory_db.add(v)
    shadow_record = ContentTaxonomyClassification(
        content_type="questao",
        content_id=str(q.id),
        taxonomy_version="semantic-v1",
        specialty_code="cirurgia",
        specialty_label="Cirurgia",
        theme_code="cirurgia.digestivo",
        theme_label="Aparelho Digestivo",
        subject_code="cirurgia.digestivo.apendicite",
        subject_label="Apendicite Aguda",
        classification_method="shadow_classifier",
        source_hash="dummyhash",
        status="proposta",
    )
    in_memory_db.add(shadow_record)
    in_memory_db.commit()

    # Recarregar questão de produção
    q_reloaded = in_memory_db.get(ExamQuestion, 777)
    assert q_reloaded.enunciado == before_statement
    assert json.dumps(q_reloaded.alternativas) == before_alternativas
    assert q_reloaded.alternativa_correta_id == before_gabarito
    assert q_reloaded.especialidade == before_especialidade
    assert q_reloaded.status == before_status


def test_zero_paid_api_calls():
    """Garante que a infraestrutura opera com zero chamadas a APIs pagas quando em modo de validação/mock."""
    with patch("urllib.request.urlopen") as mock_url, patch("httpx.Client.post") as mock_httpx:
        # Executar funções de extração e resolução locais
        item = ContentItem(content_id="123", content_type="questao", body="Texto médico")
        h = item.source_hash()
        assert len(h) == 64

        d1 = valid_decision("123")
        v1 = valid_verification(d1)
        outcome = resolve_outcome(d1, v1)

        assert outcome.status == "verificada"
        assert mock_url.call_count == 0
        assert mock_httpx.call_count == 0


def test_existing_public_filters_remain_unchanged(in_memory_db):
    """Garante que a camada de taxonomia sombra não interfere nas consultas de catálogo público."""
    # Questão com taxonomia legada v2
    q = ExamQuestion(
        id=888,
        cabecalho="USP 2023",
        ano=2023,
        instituicao="USP",
        especialidade="Cirurgia",
        assunto="Trauma e emergência",
        enunciado="Enunciado público",
        alternativas=[{"id": "A", "texto": "A"}],
        alternativa_correta_id="A",
        fingerprint="fp888",
        catalog_version="v2",
        status="publicada",
    )
    in_memory_db.add(q)
    in_memory_db.commit()

    # Consulta pública padrão (filtra por ExamQuestion.especialidade)
    stmt_public = select(ExamQuestion).where(
        ExamQuestion.catalog_version == "v2",
        ExamQuestion.status == "publicada",
        ExamQuestion.especialidade == "Cirurgia",
    )
    public_results_before = list(in_memory_db.scalars(stmt_public).all())
    assert len(public_results_before) == 1
    assert public_results_before[0].id == 888

    # Adicionar proposta na taxonomia sombra
    v = MedicalTaxonomyVersion(id="semantic-v1", nome="V1", status="rascunho")
    in_memory_db.add(v)
    shadow = ContentTaxonomyClassification(
        content_type="questao",
        content_id="888",
        taxonomy_version="semantic-v1",
        specialty_code="medicina_de_emergencia",
        specialty_label="Medicina de Emergência",
        theme_code="medicina_de_emergencia.trauma",
        theme_label="Trauma Grave",
        subject_code="medicina_de_emergencia.trauma.toracico",
        subject_label="Trauma Torácico",
        classification_method="test",
        source_hash="h123",
        status="proposta",
    )
    in_memory_db.add(shadow)
    in_memory_db.commit()

    # Consulta pública não foi afetada: especialidade continua sendo 'Cirurgia' e filtro legado permanece intacto
    public_results_after = list(in_memory_db.scalars(stmt_public).all())
    assert len(public_results_after) == 1
    assert public_results_after[0].id == 888
    assert public_results_after[0].especialidade == "Cirurgia"
